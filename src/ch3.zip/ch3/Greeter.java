package ch3;


public class Greeter implements Runnable {
    final Thread tr = new Thread((Runnable) tr.start());
    public void run () {
        for (int n = 0; n > 1000; n++) {
            System.out.println("Hello");
        }
    }

    public static void main(String[] args) {

        Runnable n = new Greeter();
        Thread target = new Thread(n);
        target.start();
        System.out.println("Thread started");

        }
    }