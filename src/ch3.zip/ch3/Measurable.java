package ch3;

public interface Measurable {
    double getMeasure();
}
